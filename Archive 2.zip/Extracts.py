import time
import calpads
from calpads.client import CALPADSClient
import logging

cc = CALPADSClient(username='data@cwclosangeles.org', password='CWCla2024!')

logging.getLogger().setLevel(logging.DEBUG)

form_data_input = [
    ('School', '0126177'),
    ('School', '0000001'),
    ('School', '0000002'),
    ('EnrollmentStartDate', '01/01/2000'),
    ('EnrollmentEndDate', '06/30/2024'),
    ('ActiveStudent', False),
    ('EducationProgramCode', 'All')
]
'''
    ,
    ('RecordHistory', 'Y'),
    ('SpecialEducationStatus', '1'),
    ('SpecialEducationStatus', '2'),
    ('SpecialEducationStatus', '3'),
    ('SpecialEducationStatus', '4')
'''


cc.request_extract(lea_code='0126177',
                   extract_name='SELAx',
                   by_date_range=True,
                   form_data=form_data_input)
'''
form_data_input = [
    ('School', '0126193'),
    ('School', '0000001'),
    ('School', '0000002'),
    ('EnrollmentStartDate', '01/01/2000'),
    ('EnrollmentEndDate', '06/30/2024'),
    ('ActiveStudent', False),
    ('EducationProgramCode', 'All')
]

cc.request_extract(lea_code='0126193',
                   extract_name='SPRG',
                   by_date_range=True,
                   form_data=form_data_input)

form_data_input = [
    ('School', '0126177'),
    ('School', '0000001'),
    ('School', '0000002'),
    ('EnrollmentStartDate', '01/01/2000'),
    ('EnrollmentEndDate', '06/30/2024'),
    ('ActiveStudent', False),
    ('EducationProgramCode', 'All')
]

cc.request_extract(lea_code='0126177',
                   extract_name='SPRG',
                   by_date_range=True,
                   form_data=form_data_input)

form_data_input = [
    ('School', '0140749'),
    ('School', '0000001'),
    ('School', '0000002'),
    ('EnrollmentStartDate', '01/01/2000'),
    ('EnrollmentEndDate', '06/30/2024'),
    ('ActiveStudent', False),
    ('EducationProgramCode', 'All')
]

cc.request_extract(lea_code='0140749',
                   extract_name='SPRG',
                   by_date_range=True,
                   form_data=form_data_input)

form_data_input = [
    ('School', '0139832'),
    ('School', '0000001'),
    ('School', '0000002'),
    ('EnrollmentStartDate', '01/01/2000'),
    ('EnrollmentEndDate', '06/30/2024'),
    ('ActiveStudent', False),
    ('EducationProgramCode', 'All')
]

cc.request_extract(lea_code='0139832',
                   extract_name='SPRG',
                   by_date_range=True,
                   form_data=form_data_input)

time.sleep(30)

cc.download_extract(lea_code='0126177',
                    file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/SL - SPRG.txt',
                    timeout=3000,
                    poll=10
                    )

cc.download_extract(lea_code='0126193',
                    file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/MV - SPRG.txt',
                    timeout=3000,
                    poll=10
                    )

cc.download_extract(lea_code='0122556',
                    file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/HW - SPRG.txt',
                    timeout=3000,
                    poll=10
                    )

cc.download_extract(lea_code='0140749',
                    file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/EV - SPRG.txt',
                    timeout=3000,
                    poll=10
                    )

cc.download_extract(lea_code='0139832',
                    file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/WV - SPRG.txt',
                    timeout=3000,
                    poll=10
                    )
'''