import calpads
import datetime
import logging

from calpads.client import CALPADSClient

def handler():

    cc = CALPADSClient(username='data@cwclosangeles.org', password='CWCla2324!')

    logging.getLogger().setLevel(logging.DEBUG)

    form_input = {

        'LEA': 'Citizens of the World Charter School Hollywood',
        'SchoolName': {

            'Citizens of the World Charter School Hollywood-0122556': True,
            'NPS School Group for Citizens of the World Charter School Hollywood-0000001': True

        }
    }

    cc.download_report(

        lea_code='0122556',
        report_code='8.1',
        dry_run=False,
        form_data=form_input,
        file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/HW - 8.1.csv',
        download_format='csv'

    )

    form_input = {

        'SchoolName': {

            'Citizens of the World Charter School Mar Vista-0126193': True,
            'NPS School Group for Citizens of the World Charter School Mar Vista-0000001': True

        }
    }

    cc.download_report(

        lea_code='0126193',
        report_code='8.1',
        dry_run=False,
        form_data=form_input,
        file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/MV - 8.1.csv',
        download_format='csv'

    )

    form_input = {

        'SchoolName': {

            'Citizens of the World Charter School Silver Lake-0126177': True,
            'NPS School Group for Citizens of the World Charter School Silver Lake-0000001': True

        }
    }

    cc.download_report(

        lea_code='0126177',
        report_code='8.1',
        dry_run=False,
        form_data=form_input,
        file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/SL - 8.1.csv',
        download_format='csv'

    )

    form_input = {

        'SchoolName': {

            'Citizens of the World Charter School East Valley-0140749': True,
            'NPS School Group for Citizens of the World Charter School East Valley-0000001': True

        }
    }

    cc.download_report(

        lea_code='0140749',
        report_code='8.1',
        dry_run=False,
        form_data=form_input,
        file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/EV - 8.1.csv',
        download_format='csv'

    )

    form_input = {

        'SchoolName': {

            'Citizens of the World Charter School West Valley-0139832': True,
            'NPS School Group for Citizens of the World Charter School West Valley-0000001': True

        }
    }

    cc.download_report(

        lea_code='0139832',
        report_code='8.1',
        dry_run=False,
        form_data=form_input,
        file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/WV - 8.1.csv',
        download_format='csv'

    )

    form_input = {

        'FromDate': '01/01/2000',
        'ThrouDate': '06/30/2024',
        'SchoolName': {

            'Citizens of the World Charter School Silver Lake-0126177': True,
            'NPS School Group for Citizens of the World Charter School Silver Lake-0000001': True

        }

    }

    cc.download_report(

        lea_code='0126177',
        report_code='8.1a',
        dry_run=False,
        form_data=form_input,
        file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/SL - 8.1a.csv',
        download_format='csv'

    )

    form_input = {

        'FromDate': '01/01/2000',
        'ThrouDate': '06/30/2024',
        'SchoolName': {

            'Citizens of the World Charter School Hollywood-0122556': True,
            'NPS School Group for Citizens of the World Charter School Hollywood-0000001': True

        }

    }

    cc.download_report(

        lea_code='0122556',
        report_code='8.1a',
        dry_run=False,
        form_data=form_input,
        file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/HW - 8.1a.csv',
        download_format='csv'

    )

    form_input = {

        'FromDate': '01/01/2000',
        'ThrouDate': '06/30/2024',
        'SchoolName': {

            'Citizens of the World Charter School West Valley-0139832': True,
            'NPS School Group for Citizens of the World Charter School West Valley-0000001': True

        }

    }

    cc.download_report(

        lea_code='0139832',
        report_code='8.1a',
        dry_run=False,
        form_data=form_input,
        file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/WV - 8.1a.csv',
        download_format='csv'

    )

    form_input = {

        'FromDate': '01/01/2000',
        'ThrouDate': '06/30/2024',
        'SchoolName': {

            'Citizens of the World Charter School East Valley-0140749': True,
            'NPS School Group for Citizens of the World Charter School East Valley-0000001': True

        }

    }

    cc.download_report(

        lea_code='0140749',
        report_code='8.1a',
        dry_run=False,
        form_data=form_input,
        file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/EV - 8.1a.csv',
        download_format='csv'

    )

    form_input = {

        'FromDate': '01/01/2000',
        'ThrouDate': '06/30/2024',
        'SchoolName': {

            'Citizens of the World Charter School Mar Vista-0126193': True,
            'NPS School Group for Citizens of the World Charter School Mar Vista-0000001': True

        }

    }

    cc.download_report(

        lea_code='0126193',
        report_code='8.1a',
        dry_run=False,
        form_data=form_input,
        file_name='/Users/cwcstaff/Library/CloudStorage/GoogleDrive-data@cwclosangeles.org/Shared drives/Data & Analytics/Source Docs/Exports and Downloads/CALPADS/For Tableau/MV - 8.1a.csv',
        download_format='csv'

    )

if __name__ == "__main__":
    handler()